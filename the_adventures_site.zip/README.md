# The Adventures of an Engineer

© 2025 Joly Jayson  
Лицензия: Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International (CC BY-NC-ND 4.0)

Это статическая версия книги, разбитая по томам и главам. Файлы глав находятся в папке `chapters/volXX/chYY.html`.

Оглавление автоматически сгенерировано в `index.html`.
